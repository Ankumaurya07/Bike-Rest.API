//input add data

function openNav() {
  document.getElementById("mySidenav").style.width = "350px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}


let addcompany = document.getElementById("company")
let addmodel = document.getElementById("model")
let addengine = document.getElementById("engine")
let addmileage = document.getElementById("mileage")
let addprice = document.getElementById("price")
let addimg = document.getElementById("img")
let addbtn = document.getElementById("addbutton")

//filter by compny

let filterhonda = document.getElementById("Honda")
let filterRoyal = document.getElementById("Royal")
let filterYamaha = document.getElementById("Yamaha")
let filterKTM = document.getElementById("KTM")
let filterTVS = document.getElementById("TVS")

// updated data

let updatebtn = document.getElementById("u-btn")
let updatecom = document.getElementById("u-company")
let updatemd = document.getElementById("u-model")
let updateen = document.getElementById("u-engine")
let updatemila = document.getElementById("u-mileage")
let updatepr = document.getElementById("u-price")
let updateimg = document.getElementById("u-img")
let updateid = document.getElementById("u-id")


let allBikes = [];

function fatchdata()
{
    fetch("http://localhost:3000/bikes")
    .then((res)=>res.json())
    .then((data)=>{
        cardlist(data)
        allBikes = data
    })
    .catch((err)=>console.log(err))
}
fatchdata()

function cardlist(data)
{
    const store = data.map((el)=>card(el.id,el.img,el.engine,el.price,el.company,el.mileage,el.model))
    document.getElementById("bikeContainer").innerHTML =store.join("")
}

function card(id,img,engine,price,company,mileage,model,)
{
    let singelcard = `
    <div class="card">
            <div>
            <img src="${img}" alt="${model}" />
            </div>
             <div class ="slide">
            <h3> ${model}</h3>
            <p><strong>Engine:</strong> ${engine}</p>
            <p><strong>Mileage:</strong> ${mileage}</p>
            <p><strong>Price:</strong> ${price}</p>
            <div class="card-btn">
            <a href="#" data-id=${id} class="card-li">EDIT</a>
            <button data-id=${id} class="card-b">DELETE</button>
             </div>
            </div>
    </div>
            `

    return singelcard
}

    addbtn.addEventListener("click",(data)=>{
      let bikes = {
        img:addimg.value,
        model:addmodel.value,
        engine:addengine.value,
        company:addcompany.value,
        price:addprice.value,
        mileage:addmileage.value
      }
      fetch(`http://localhost:3000/bikes`,{
        method : "POST",
        headers:{
            'Content-Type': 'application/json',
        },
        body:JSON.stringify(bikes)
    }).then(res => res.json())
    .then(data =>{
        console.log(data)
        alert("product added")
    })
    .catch(error =>{
        console.log(error)
        alert("something wrong")
      })
    })
    //catogery filter

   
filterKTM.addEventListener("click",()=>{
  let filterdata =  allBikes.filter((el)=>el.company === "KTM")  
  console.log(filterdata)
  cardlist(filterdata)
})
filterRoyal.addEventListener("click",()=>{
  let filterdata =  allBikes.filter((el)=>el.company === "Royal Enfield")  
  console.log(filterdata)
  cardlist(filterdata)
})
filterTVS.addEventListener("click",()=>{
  let filterdata =  allBikes.filter((el)=>el.company === "TVS")  
  console.log(filterdata)
  cardlist(filterdata)
})
filterYamaha.addEventListener("click",()=>{
  let filterdata =  allBikes.filter((el)=>el.company === "Yamaha")  
  console.log(filterdata)
  cardlist(filterdata)
})
filterhonda.addEventListener("click",()=>{
  let filterdata =  allBikes.filter((el)=>el.company === "Honda")  
  console.log(filterdata)
  cardlist(filterdata)
})

// delete bike

document.addEventListener("click",(e)=>{
  if(e.target.classList.contains("card-b"))
  {
      Deletepro(e.target.dataset.id)
  }
})

function Deletepro(id)
{
  fetch(`http://localhost:3000/bikes/${id}`,{
      method:"DELETE",
  })
  .then((res)=>res.json())
  .then((data)=>{
      alert("DELETED....")
      console.log(data)
  })
  .catch((err)=>console.log(err))
}

//update

document.addEventListener("click",(e)=>{
  if(e.target.classList.contains("card-li"))
  {
      let id = e.target.dataset.id
      fillform(id)
  }
})
function fillform(id)
{
  fetch(`http://localhost:3000/bikes/${id}`)
  .then((res) => res.json())
  .then((data) => {
      console.log(data)
      updateid.value = data.id
      updatemila.value = data.mileage
      updatemd.value = data.model
      updatecom.value = data.company
      updatepr.value = data.price
      updateimg.value = data.img
      updateen.value = data.engine

  })
  .catch((err) => console.log(err))
}

updatebtn.addEventListener("click",()=>{
  let updateprodata = {
    img:updateimg.value,
    model:updatemd.value,
    engine:updateen.value,
    company:updatecom.value,
    price:updatepr.value,
    mileage:updatemila.value,
    id:updateid.value

  }

  fetch(`http://localhost:3000/bikes/${updateprodata.id}`,{

      method:"PUT",
      headers:{
          'Content-Type': 'application/json',
      },
      body:JSON.stringify(updateprodata)

  }).then((res)=>res.json())
  .then((data)=>{
      alert(" data updated.....")
  })
  .catch((err)=>console.log(err))
})

